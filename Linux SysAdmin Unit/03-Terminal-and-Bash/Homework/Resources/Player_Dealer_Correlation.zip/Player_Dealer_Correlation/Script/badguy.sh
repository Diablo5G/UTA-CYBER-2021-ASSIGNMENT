#!/bin/bash
cat 03* | grep - > Roulette_Losses
cat 03* | grep "Mylie Schmidt" | wc -l 
