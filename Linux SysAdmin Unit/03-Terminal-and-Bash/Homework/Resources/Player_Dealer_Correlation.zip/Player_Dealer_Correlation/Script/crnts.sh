#!/bin/bash
mkdir Player_Analysis
cd Player_Analysis
touch Notes_Player_Analysis 
cd ..
mkdir Dealer_Analysis
cd Dealer_Analysis
touch Notes_Dealer_Analysis
cd ..
mkdir Player_Dealer_Correlation
cd Player_Dealer_Correlation
touch Notes_Player_Dealer_Correlation

